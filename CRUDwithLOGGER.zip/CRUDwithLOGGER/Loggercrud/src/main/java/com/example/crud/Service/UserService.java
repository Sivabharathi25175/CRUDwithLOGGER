package com.example.crud.Service;

import java.util.List;
import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.crud.Controller.UserController;
import com.example.crud.Entity.UserDTO;
import com.example.crud.Repository.UserREpository;

import ch.qos.logback.classic.Logger;

@Service
public class UserService {
	Logger logger=(Logger) LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserREpository repo;
	
	public UserDTO  save(UserDTO user)
	{
		logger.trace("save user service access");
		return repo.save(user);
	}

	

	public UserDTO finddd(long id) {
		// TODO Auto-generated method stub
		logger.trace("findd  service access");
		UserDTO user=repo.findAllById(id);
		return user;
	}



//	public UserDTO get(long id) {
//		// TODO Auto-generated method stub
//		logger.trace("getby id service access");
//		return repo.findById(id).get();
//	}



	public Optional<UserDTO> getbyid(Long id) {
		logger.trace("getby id service access");
		// TODO Auto-generated method stub
		return repo.findById(id);
	}



	public List<UserDTO> findall() {
		// TODO Auto-generated method stub
		logger.trace("findall id service access");
		return repo.findAll();
	}



	public UserDTO upadte(long id, UserDTO user2) {
		// TODO Auto-generated method stub
		UserDTO user=repo.findAllById(id);
		String na=user.getUsername();
		logger.trace("findall id service access"+na);
		user.setUsername(user2.getUsername());
		
		user.setNumber(user.getNumber());
		if(user2.getPassword()!=null) user.setPassword(user2.getPassword());
		user.setPassword(user2.getPassword());
		user.setEmail(user2.getEmail());
		
		return repo.save(user);
	}

	

}
