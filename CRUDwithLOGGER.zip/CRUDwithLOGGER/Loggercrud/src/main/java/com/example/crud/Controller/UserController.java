package com.example.crud.Controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.crud.Entity.UserDTO;
import com.example.crud.Service.UserService;

import ch.qos.logback.classic.Logger;


@RestController
public class UserController {
	
	Logger logger=(Logger) LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserService service;
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ResponseEntity<?> saveUser(@RequestBody UserDTO user) throws Exception {
		logger.trace("register end point access");
		
		return ResponseEntity.ok(service.save(user));
		
	
	}

	@RequestMapping(value = "/findbyid", method = RequestMethod.GET)
		public Optional<UserDTO> investmentidadd( @RequestParam("id") long id)
		{
		logger.trace("findby id end point access");
		    return service.getbyid(id);
		}

	@RequestMapping(value = "/findbyall", method = RequestMethod.GET)
		public List<UserDTO> findall()
		{
		logger.trace("findbyall end point access");
		    return service.findall();
		}
	
	@RequestMapping(value = "/updateALL", method = RequestMethod.POST)
	public ResponseEntity<?> saveUser(@RequestParam long id,/*@RequestParam ("name")String name*/@RequestBody UserDTO user) throws Exception {
		logger.trace("update end point access");
		
		return ResponseEntity.ok(service.upadte(id,user));
		
	
	}
}


